```{include} ../../README.md
```

## Other pages

```{toctree}
:maxdepth: 2

reference
changelog
```
