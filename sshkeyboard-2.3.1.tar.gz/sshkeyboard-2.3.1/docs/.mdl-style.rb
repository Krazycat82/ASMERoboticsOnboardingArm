all
exclude_rule 'MD002'
exclude_rule 'MD023'
exclude_rule 'MD026'
exclude_rule 'MD033'
exclude_rule 'MD036'
exclude_rule 'MD040'
exclude_rule 'MD041'
rule 'MD013', :line_length => 80, :code_blocks => false
rule 'MD009', :br_spaces => 2
rule 'MD029', :style => :ordered
rule 'MD007', :indent => 4